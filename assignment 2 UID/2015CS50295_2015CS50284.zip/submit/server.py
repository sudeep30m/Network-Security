import time
import json
import socket
import random
from Crypto.PublicKey import RSA
from OpenSSL import crypto, SSL
from Crypto.Hash import SHA


def decrypt(cipher):
    f2 = open('privateKey.pem','r')
    private_key = RSA.importKey(f2.read())
    f2.close()
    print(type(cipher))
    decrypted = private_key.decrypt(cipher)
    data = json.loads(decrypted)
    return data

def verify(data):
    return bool(random.getrandbits(1))

def createCertificate(data, answer):

    query = json.dumps(data).encode('ascii')
    hashQuery = SHA.new(query).hexdigest()
    
    cert = {
        "hashQuery":hashQuery,
        "answer":answer
    }
    print("certificate is ", cert)
    certDump = json.dumps(cert).encode('ascii')
    hashCert = SHA.new(certDump).hexdigest()
 
    f2 = open('privateKey.pem','r')
    private_key = RSA.importKey(f2.read())
    signature = private_key.encrypt(hashCert, 32)[0]
    responseDict = {
        "cert": cert,
        "signature": signature
    }
    print(responseDict)
    response = json.dumps(responseDict, encoding='latin1')
    return response

    # k = crypto.PKey()
    # k.generate_key(crypto.TYPE_RSA, 1024)
    # with open(public_key_filename) as f:
    #     public_key_data = f.read()
    # open(join(cert_dir, KEY_FILE), "rt").read(
    #     crypto.dump_privatekey(crypto.FILETYPE_PEM, k))

    # create a self-signed cert
    # cert = crypto.X509()
    # cert.get_subject().OU = ""
    # cert.set_serial_number(1000)
    # cert.gmtime_adj_notBefore(0)
    # cert.gmtime_adj_notAfter(10*365*24*60*60)
    # cert.get_issuer().OU = "UIDAI"
    # # cert.set_pubkey(k)
    # cert.sign(k, 'sha1')
    # newext = crypto.X509Extension('nsComment', 1, '')
    # cert.add_extensions([newext])
    # open(join(cert_dir, CERT_FILE), "wt").write(
    #     crypto.dump_certificate(crypto.FILETYPE_PEM, cert))
    # open(join(cert_dir, KEY_FILE), "wt").write(
    #     crypto.dump_privatekey(crypto.FILETYPE_PEM, k))
        
# create_self_signed_cert(".")



serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
host = socket.gethostbyname('localhost')
port = 9999
serversocket.bind((host, port))
serversocket.listen(5)

print("Listening on port ",port)


while True:
    # establish a connection
    clientsocket,addr = serversocket.accept()      
    print("Got a connection from %s" % str(addr))
    # currentTime = time.ctime(time.time()) + "\r\n"
    # clientsocket.send(currentTime.encode('ascii'))
    cipher = clientsocket.recv(4096)
    data = decrypt(cipher)
    ans = verify(data)
    print(data)
    response = createCertificate(data, ans)
    clientsocket.send(response)
    clientsocket.close()



